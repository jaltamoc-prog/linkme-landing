# v1.081 Google Wallet visible y Apple Wallet proximamente
# Integra el logotipo oficial de Google Wallet como respaldo secundario en el
# encabezado y en su bloque de beneficio; anuncia Apple Wallet sin presentarlo
# todavía como una función disponible.
# v1.080 Google Wallet como ventaja de cero friccion
# Comunica que el propietario puede llevar su QR en Google Wallet sin exigir
# que sus prospectos descarguen una app o utilicen Wallet.
# Base: v1.079 CTA clicable del chat y cero friccion
# Convierte la liga oficial de creacion en el boton "Crear mi CONVERTE".
# Base: v1.078 Chat CONVERTE colaborador comercial
# Actualiza el saludo visible y la marca del chat; conserva su sesion y endpoint.
# Base: v1.077 Landing CONVERTE.ONE - sustitución exclusiva de marca visible
# Base: v1.076 Landing linkme.life® - contenido, navegación audiovisual, legal e identidad
# v1.058 Landing LinkMe - chat compacto, minimizable y sesión controlada
# v1.057 Landing LinkMe - chat movil compacto y cierre siempre accesible
# v1.056 Landing LinkMe - burbuja flotante de LinkMe contigo siempre visible
# v1.055 Landing LinkMe - LinkMe contigo conversacional
# v1.054 Landing LinkMe - videos visibles con texto legible
# v1.052 Landing LinkMe - reemplazo de videos 1 y 2
# v1.051 Landing LinkMe - autoplay compatible con iPhone y Android
# v1.050 Landing LinkMe - texto limpio visible sobre video
# v1.049 Landing LinkMe - videos full-screen por sección
# v1.048 Landing LinkMe - videos protagonistas y contraste editorial
# v1.047 Landing LinkMe - motion-first con videos originales de LinkMe
# v1.046 Landing LinkMe - diseño editorial inmersivo motion-first
# v1.045 Landing LinkMe - marco único responsivo sin SVG superpuesto
# v1.044 Landing LinkMe - pantalla ajustada detrás del notch
# v1.043 Landing LinkMe - encaje exacto dentro del contorno original
# v1.042 Landing LinkMe - medios ajustados a la pantalla del celular
# v1.041 Landing LinkMe - recorte inferior dentro del celular
# v1.040 Landing LinkMe - pantalla ajustada dentro del celular
# v1.039 Landing LinkMe - un solo contorno de celular
# v1.038 Landing LinkMe - pantallas dentro del contorno de celular
# v1.037 Landing LinkMe - contorno de celular en imagen y videos
# v1.036 Landing LinkMe - propuesta de valor centrada en el beneficio
# v1.035 Landing LinkMe - ajustes de redacción y estructura
# v1.034 Landing LinkMe - precios México/internacional
# Reemplaza la imagen principal y los videos de perfil privado y público.
# v1.032 Landing LinkMe - FAQ acceso desde cualquier dispositivo
from flask import Flask, render_template, redirect, Response, request
import os

from herramientas.calculadora_isr import calculadora_isr_bp

app = Flask(__name__)
app.register_blueprint(calculadora_isr_bp, url_prefix="/calculadora-isr")

# v1.027 - Cache busting para que celular cargue última versión de CSS/JS
ASSET_VERSION = "1081"

@app.context_processor
def inject_asset_version():
    return {"asset_version": ASSET_VERSION}


def detectar_mercado():
    pais = (
        request.headers.get("CF-IPCountry")
        or request.headers.get("CloudFront-Viewer-Country")
        or request.headers.get("X-Country-Code")
        or ""
    ).strip().upper()
    if pais:
        return "mxn" if pais == "MX" else "usd"
    return "mxn" if "ES-MX" in (request.headers.get("Accept-Language") or "").upper() else "usd"

@app.after_request
def add_cache_headers(response):
    content_type = response.headers.get("Content-Type", "")
    if "text/html" in content_type:
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


# v1.025 Landing LinkMe - header movil botones chips premium
# Dominio comercial: https://www.linkme.style
# La landing vende. La app operativa crea/edita LinkMe.

APP_CREATE_URL = "https://linkme-mvp.onrender.com/nuevo"  # temporal hasta activar DNS app.linkme.style
LINKME_CHAT_API_URL = os.getenv(
    "LINKME_CHAT_API_URL",
    "https://linkme-mvp.onrender.com/s/linkme-contigo",
).strip()

@app.after_request
def aplicar_headers_basicos(response):
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "SAMEORIGIN"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    if request.path.startswith("/static/"):
        response.headers["Cache-Control"] = "public, max-age=604800"
    else:
        response.headers["Cache-Control"] = "no-store"
    return response

@app.route("/")
def index():
    return render_template(
        "index.html",
        login_url="https://linkme-mvp.onrender.com/s/in",
        create_url="/nuevo",
        market=detectar_mercado(),
        chat_api_url=LINKME_CHAT_API_URL,
    )

@app.route("/crearmilinkme")
def crearmilinkme():
    return redirect(APP_CREATE_URL, code=302)  # compatibilidad: ruta antigua

@app.route("/nuevo")
def nuevo():
    return redirect(APP_CREATE_URL, code=302)

@app.route("/privacidad")
def privacidad():
    return render_template("privacidad.html", create_url="/nuevo")

@app.route("/terminos")
def terminos():
    return render_template("terminos.html", create_url="/nuevo")

@app.route("/reembolso")
def reembolso():
    return render_template("reembolso.html", create_url="/nuevo")


@app.route("/favicon.ico")
def favicon():
    return app.send_static_file("img/linkme-life-icon.png")

@app.route("/health")
def health():
    return Response("OK", status=200, mimetype="text/plain")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=False)
